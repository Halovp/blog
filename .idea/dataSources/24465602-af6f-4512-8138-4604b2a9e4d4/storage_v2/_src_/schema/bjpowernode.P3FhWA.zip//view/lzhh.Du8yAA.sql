create view lzhh as
select `bjpowernode`.`emp`.`EMPNO`    AS `EMPNO`,
       `bjpowernode`.`emp`.`ENAME`    AS `ENAME`,
       `bjpowernode`.`emp`.`JOB`      AS `JOB`,
       `bjpowernode`.`emp`.`MGR`      AS `MGR`,
       `bjpowernode`.`emp`.`HIREDATE` AS `HIREDATE`,
       `bjpowernode`.`emp`.`SAL`      AS `SAL`,
       `bjpowernode`.`emp`.`COMM`     AS `COMM`,
       `bjpowernode`.`emp`.`DEPTNO`   AS `DEPTNO`
from `bjpowernode`.`emp`;

